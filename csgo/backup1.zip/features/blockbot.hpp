#pragma once
#include "../sdk/sdk.hpp"

namespace features {
    namespace blockbot {
        void run( ucmd_t* ucmd, vec3_t& move_ang );
    }
}