#pragma once
#include "../sdk/sdk.hpp"

namespace features {
    namespace legitbot {
        void run( ucmd_t* ucmd );
    }
}