﻿#pragma once
#include "../sdk/sdk.hpp"

namespace features {
	namespace glow {
		void cache_entities( );
	}
}