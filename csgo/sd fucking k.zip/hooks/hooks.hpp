#pragma once

namespace hooks {
	void init ( );
}