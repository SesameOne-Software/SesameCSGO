#include "globals.hpp"
#include "sdk/sdk.hpp"

player_t* g::local = nullptr;
ucmd_t* g::ucmd = nullptr;
bool g::send_packet = true;