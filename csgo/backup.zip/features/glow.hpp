﻿#pragma once
#include <sdk.hpp>

namespace features {
	namespace glow {
		void cache_entities( );
	}
}