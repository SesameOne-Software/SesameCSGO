﻿#include "other_visuals.hpp"
#include "../globals.hpp"
#include "lagcomp.hpp"
#include <deque>
#include <mutex>

float features::spread_circle::total_spread = 0.0f;

bool features::get_visuals ( player_t* pl, oxui::visual_editor::settings_t** out ) {
	OPTION ( oxui::visual_editor::settings_t, vis_local, "Sesame->C->Local->Visual Editor->Visual Editor Data", oxui::object_visual_editor );
	OPTION ( oxui::visual_editor::settings_t, vis_enemy, "Sesame->C->Enemy->Visual Editor->Visual Editor Data", oxui::object_visual_editor );
	OPTION ( oxui::visual_editor::settings_t, vis_team, "Sesame->C->Team->Visual Editor->Visual Editor Data", oxui::object_visual_editor );

	if ( !pl || !pl->alive( ) || !pl->idx( ) || pl->idx( ) > csgo::i::globals->m_max_clients )
		return false;

	if ( pl == g::local ) {
		*out = &vis_local;
		return true;
	}

	if ( g::local->team ( ) != pl->team ( ) ) {
		*out = &vis_enemy;
		return true;
	}

	*out = &vis_team;
	return true;
}

void features::offscreen_esp::draw ( ) {
	OPTION ( double, offscreen_arrow_distance, "Sesame->C->Other->World->Offscreen Arrow Distance", oxui::object_slider );
	OPTION ( double, offscreen_arrow_size, "Sesame->C->Other->World->Offscreen Arrow Size", oxui::object_slider );
	OPTION ( bool, offscreen_esp, "Sesame->C->Other->World->Offscreen ESP", oxui::object_checkbox );	
	OPTION ( oxui::color, spread_circle_clr, "Sesame->C->Other->World->Offscreen ESP Color", oxui::object_colorpicker );

	if ( !g::local || !offscreen_esp )
		return;

	int w = 0, h = 0;
	render::screen_size ( w, h );

	vec3_t center ( w * 0.5f, h * 0.5f, 0.0f );

	const auto calc_distance = offscreen_arrow_distance / 100.0f * ( h * 0.5f );

	for ( auto i = 1; i <= csgo::i::globals->m_max_clients; i++ ) {
		const auto pl = csgo::i::ent_list->get< player_t* > ( i );

		if ( !pl || !pl->alive() || pl->dormant() || pl->team() == g::local->team() )
			continue;

		vec3_t screen;
		
		auto interp_origin = lagcomp::data::cham_records [ pl->idx ( ) ].m_bones1 [ 1 ].origin ( );

		if ( !csgo::render::world_to_screen ( screen, interp_origin ) ) {
			auto target_ang = csgo::vec_angle ( center - screen );
			target_ang.y = csgo::normalize ( target_ang.y - 90.0f );

			auto top_ang = csgo::vec_angle ( vec3_t ( 0.0f, -calc_distance - offscreen_arrow_size * 0.5f ) ) + target_ang;
			auto left_ang = csgo::vec_angle ( vec3_t ( -offscreen_arrow_size * 0.5f, -calc_distance + offscreen_arrow_size * 0.5f ) ) + target_ang;
			auto right_ang = csgo::vec_angle ( vec3_t ( offscreen_arrow_size * 0.5f, -calc_distance + offscreen_arrow_size * 0.5f ) ) + target_ang;

			top_ang.y = csgo::normalize ( top_ang.y );
			left_ang.y = csgo::normalize ( left_ang.y );
			right_ang.y = csgo::normalize ( right_ang.y );

			const auto mag1 = calc_distance + offscreen_arrow_size * 0.5f;
			const auto mag2 = calc_distance - offscreen_arrow_size * 0.5f;

			const auto top_pos = center + csgo::angle_vec ( top_ang ) * mag1;
			const auto left_pos = center + csgo::angle_vec ( left_ang ) * mag2;
			const auto right_pos = center + csgo::angle_vec ( right_ang ) * mag2;

			render::polygon ( { {top_pos.x, top_pos.y}, {left_pos.x, left_pos.y}, {right_pos.x, right_pos.y} }, D3DCOLOR_RGBA ( spread_circle_clr.r, spread_circle_clr.g, spread_circle_clr.b, spread_circle_clr.a ), false );
			render::polygon ( { {top_pos.x, top_pos.y}, {left_pos.x, left_pos.y}, {right_pos.x, right_pos.y} }, D3DCOLOR_RGBA ( spread_circle_clr.r - 33, spread_circle_clr.g - 33, spread_circle_clr.b - 33, spread_circle_clr.a ), true );
		}
	}
}

void features::spread_circle::draw ( ) {
	OPTION ( double, custom_fov, "Sesame->C->Other->Removals->Custom FOV", oxui::object_slider );
	OPTION ( oxui::color, spread_circle_clr, "Sesame->C->Other->World->Spread Circle Color", oxui::object_colorpicker );
	OPTION ( bool, spread_circle, "Sesame->C->Other->World->Spread Circle", oxui::object_checkbox );
	OPTION ( bool, gradient_spread_circle, "Sesame->C->Other->World->Gradient Spread Circle", oxui::object_checkbox );
	
	int w = 0, h = 0;
	render::screen_size ( w, h );

	if ( !g::local || !g::local->alive() || !g::local->weapon ( ) || !spread_circle || !total_spread )
		return;

	const auto weapon = g::local->weapon ( );
	const auto radius = ( total_spread * 320.0f ) / std::tanf ( csgo::deg2rad( custom_fov ) * 0.5f );

	if ( gradient_spread_circle ) {
		auto x = w / 2;
		auto y = h / 2;

		std::vector< render::vtx_t > circle ( 48 + 2 );

		auto pi = D3DX_PI;
		const auto angle = 0.0f;

		circle [ 0 ].x = static_cast< float > ( x ) - 0.5f;
		circle [ 0 ].y = static_cast< float > ( y ) - 0.5f;
		circle [ 0 ].z = 0;
		circle [ 0 ].rhw = 1;
		circle [ 0 ].color = D3DCOLOR_RGBA ( 0, 0, 0, 0 );

		for ( auto i = 1; i < 48 + 2; i++ ) {
			circle [ i ].x = ( float ) ( x - radius * std::cosf ( pi * ( ( i - 1 ) / ( 48.0f / 2.0f ) ) ) ) - 0.5f;
			circle [ i ].y = ( float ) ( y - radius * std::sinf ( pi * ( ( i - 1 ) / ( 48.0f / 2.0f ) ) ) ) - 0.5f;
			circle [ i ].z = 0;
			circle [ i ].rhw = 1;
			circle [ i ].color = D3DCOLOR_RGBA ( spread_circle_clr.r, spread_circle_clr.g, spread_circle_clr.b, spread_circle_clr.a );
		}

		const auto _res = 48 + 2;

		for ( auto i = 0; i < _res; i++ ) {
			circle [ i ].x = x + std::cosf ( angle ) * ( circle [ i ].x - x ) - std::sinf ( angle ) * ( circle [ i ].y - y ) - 0.5f;
			circle [ i ].y = y + std::sinf ( angle ) * ( circle [ i ].x - x ) + std::cosf ( angle ) * ( circle [ i ].y - y ) - 0.5f;
		}

		IDirect3DVertexBuffer9* vb = nullptr;

		csgo::i::dev->CreateVertexBuffer ( ( 48 + 2 ) * sizeof ( render::vtx_t ), D3DUSAGE_WRITEONLY, D3DFVF_XYZRHW | D3DFVF_DIFFUSE, D3DPOOL_DEFAULT, &vb, nullptr );

		void* verticies;
		vb->Lock ( 0, ( 48 + 2 ) * sizeof ( render::vtx_t ), ( void** ) &verticies, 0 );
		std::memcpy ( verticies, &circle [ 0 ], ( 48 + 2 ) * sizeof ( render::vtx_t ) );
		vb->Unlock ( );

		csgo::i::dev->SetStreamSource ( 0, vb, 0, sizeof ( render::vtx_t ) );
		csgo::i::dev->DrawPrimitive ( D3DPT_TRIANGLEFAN, 0, 48 );

		if ( vb )
			vb->Release ( );
	}
	else {
		render::circle ( w / 2, h / 2, radius, 48, D3DCOLOR_RGBA ( spread_circle_clr.r, spread_circle_clr.g, spread_circle_clr.b, spread_circle_clr.a ) );
		render::circle ( w / 2, h / 2, radius, 48, D3DCOLOR_RGBA( spread_circle_clr.r, spread_circle_clr.g, spread_circle_clr.b, spread_circle_clr.a ), true );
	}
}