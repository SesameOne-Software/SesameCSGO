#pragma once
#include <sdk.hpp>

namespace features {
	namespace movement {
		void run( ucmd_t* ucmd );
	}
}