#pragma once
#include <sdk.hpp>

namespace features {
	namespace movement {
		void run( ucmd_t* ucmd, vec3_t& old_angs );
	}
}