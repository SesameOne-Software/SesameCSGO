#pragma once
#include <sdk.hpp>

namespace features {
	namespace antiaim {
		void simulate_lby( );
		void run( ucmd_t* ucmd );
	}
}