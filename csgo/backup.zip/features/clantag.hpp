#pragma once
#include <sdk.hpp>

namespace features {
	namespace clantag {
		void run( ucmd_t* ucmd );
	}
}