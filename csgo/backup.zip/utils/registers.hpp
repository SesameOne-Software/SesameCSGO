#pragma once

#define REG void* ecx, void* edx
#define REG_OUT ecx, edx